const admin_access = ["admin@asu.edu", "admin2@asu.edu"];
module.exports = admin_access;